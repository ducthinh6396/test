#!/bin/bash
exec /usr/sbin/httpd -D FOREGROUND
