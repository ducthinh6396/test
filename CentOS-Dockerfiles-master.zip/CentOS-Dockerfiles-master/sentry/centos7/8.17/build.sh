#! /usr/bin/bash

echo "I'm running in build."
